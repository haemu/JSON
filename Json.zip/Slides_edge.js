/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'btn',
            type:'rect',
            rect:['228px','368px','118px','26px','auto','auto'],
            cursor:['pointer'],
            borderRadius:["15px 15px","15px 15px","15px 15px","15px 15px"],
            fill:["rgba(192,192,192,1)"],
            stroke:[0,"rgb(0, 0, 0)","none"],
            boxShadow:["",3,3,3,0,"rgba(0,0,0,0.65)"]
         },
         {
            id:'photo',
            type:'rect',
            rect:['87px','109px','400px','250px','auto','auto'],
            cursor:['pointer'],
            borderRadius:["15px 15px","15px 15px","15px 15px","15px 15px"],
            fill:["rgba(192,192,192,1)"],
            stroke:[0,"rgba(0,0,0,1)","none"],
            boxShadow:["",3,3,3,0,"rgba(0,0,0,0.65)"]
         },
         {
            id:'pillar',
            type:'text',
            rect:['0px','0px','550px','33px','auto','auto'],
            text:"The Five Pillars of Islam",
            align:"center",
            font:['Arial, Helvetica, sans-serif',24,"rgba(0,0,0,1)","normal","none",""]
         },
         {
            id:'what',
            type:'text',
            rect:['18px','45px','519px','85px','auto','auto'],
            clip:['rect(0px 519px 59px 0px)'],
            text:"Click on the buttons to learn about the Five Pillars of Islam.",
            align:"left",
            font:['Arial, Helvetica, sans-serif',18,"rgba(0,0,0,1)","normal","none","normal"]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_what}": [
            ["style", "top", '45px'],
            ["style", "clip", [0,519,59,0], {valueTemplate:'rect(@@0@@px @@1@@px @@2@@px @@3@@px)'} ],
            ["style", "height", '85px'],
            ["style", "width", '519px'],
            ["style", "left", '18px'],
            ["style", "font-size", '18px']
         ],
         "${_btn}": [
            ["style", "border-top-left-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["subproperty", "boxShadow.blur", '3px'],
            ["style", "border-bottom-right-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '228px'],
            ["style", "top", '368px'],
            ["style", "border-bottom-left-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-top-right-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["subproperty", "boxShadow.color", 'rgba(0,0,0,0.65)'],
            ["style", "height", '26px'],
            ["subproperty", "boxShadow.offsetV", '3px'],
            ["subproperty", "boxShadow.offsetH", '3px'],
            ["style", "cursor", 'pointer']
         ],
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '400px'],
            ["style", "width", '550px']
         ],
         "${_photo}": [
            ["style", "border-top-left-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["subproperty", "boxShadow.blur", '3px'],
            ["style", "border-bottom-right-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '87px'],
            ["style", "width", '400px'],
            ["style", "top", '109px'],
            ["style", "border-bottom-left-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "cursor", 'pointer'],
            ["subproperty", "boxShadow.color", 'rgba(0,0,0,0.648438)'],
            ["style", "height", '250px'],
            ["subproperty", "boxShadow.offsetV", '3px'],
            ["subproperty", "boxShadow.offsetH", '3px'],
            ["style", "border-top-right-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ]
         ],
         "${_pillar}": [
            ["style", "top", '0px'],
            ["style", "left", '0px'],
            ["style", "text-align", 'center'],
            ["style", "width", '550px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
},
"slide": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
   dom: [
   {
      boxShadow: ['',3,3,3,0,'rgba(0,0,0,0.65)'],
      rect: ['0px','0px','400px','250px','auto','auto'],
      borderRadius: ['15px 15px','15px 15px','15px 15px','15px 15px'],
      type: 'rect',
      id: 'photo',
      stroke: [0,'rgba(0,0,0,1)','none'],
      cursor: ['pointer'],
      fill: ['rgba(192,192,192,1)']
   },
   {
      rect: ['-83px','-137px','550px','33px','auto','auto'],
      font: ['Arial, Helvetica, sans-serif',24,'rgba(0,0,0,1)','normal','none',''],
      id: 'pillar',
      text: 'placeholder',
      align: 'center',
      type: 'text'
   },
   {
      rect: ['-65px','-92px','519px','85px','auto','auto'],
      font: ['Arial, Helvetica, sans-serif',18,'rgba(0,0,0,1)','normal','none','normal'],
      id: 'what',
      text: 'placeholder',
      align: 'left',
      type: 'text'
   }],
   symbolInstances: [
   ]
   },
   states: {
      "Base State": {
         "${_what}": [
            ["style", "top", '-92px'],
            ["style", "height", '85px'],
            ["style", "font-size", '18px'],
            ["style", "left", '-65px'],
            ["style", "width", '519px']
         ],
         "${symbolSelector}": [
            ["style", "height", '250px'],
            ["style", "width", '400px']
         ],
         "${_pillar}": [
            ["style", "top", '-137px'],
            ["style", "text-align", 'center'],
            ["style", "left", '-83px'],
            ["style", "width", '550px']
         ],
         "${_photo}": [
            ["style", "border-top-left-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["subproperty", "boxShadow.blur", '3px'],
            ["style", "border-bottom-right-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "left", '0px'],
            ["style", "width", '400px'],
            ["style", "top", '0px'],
            ["style", "border-bottom-left-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["style", "border-top-right-radius", [15,15], {valueTemplate:'@@0@@px @@1@@px'} ],
            ["subproperty", "boxShadow.color", 'rgba(0,0,0,0.65)'],
            ["style", "height", '250px'],
            ["subproperty", "boxShadow.offsetV", '3px'],
            ["subproperty", "boxShadow.offsetH", '3px'],
            ["style", "cursor", 'pointer']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 0,
         autoPlay: true,
         timeline: [
         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-96901133");
